package assignment01;

import static org.junit.Assert.*;

import org.junit.Test;

public class NamedObjectTest {

	NamedObject tempOne = new NamedObject("TempOne", 1);
	NamedObject tempTwo = new NamedObject("TempTwo", 2);
	NamedObject tempFour = new NamedObject("TempFour", null);
	NamedObject tempFive = new NamedObject("TempOne", 1);
	
	@Test(expected = IllegalArgumentException.class)
	public void TestConstructorToMakeSureItDoesNotAllowNullName(){
		NamedObject tempThree = new NamedObject(null, 3);
	}
	
	@Test
	public void TestGetNameAndSetName(){
		if(tempOne.getName() != "TempOne"){
			fail("The names is not correct");
			}
		tempTwo.setName("Temp2");
		if(tempTwo.getName() != "Temp2"){
			fail("The name for tempTwo has not been changed to Temp2");
			}
	}
	
	@Test
	public void TestForEqualityOfTwoNonNullObjects() {
		//Test whether the .equals() method works in comparison to the == operator. 
		//Note: == uses references where .equals checks for actual equality of names and objects.
		if(tempOne.equals(tempFive)){
			System.out.println("tempOne and tempFive are the same using .equals()");
			}
		if(tempOne == tempFive){
			System.out.println("tempOne and tempFive are the same using ==");
			}
		if(tempOne.equals(tempTwo)){
			System.out.println("tempOne and tempTwo are the same using .equals()");
			}
		if(tempOne == tempTwo){
			System.out.println("tempOne and tempTwo are the same using ==");
			}
	}
	
	@Test
	public void TestEqualityOfNullObjects(){	
		NamedObject tempSix = new NamedObject("TempFour", null);
		if(tempFour.equals(tempSix)){
			System.out.println("tempFour and tempSix are the same using .equals()");
		}
	}
	
	
}
